# Microprocessors
Repository for Physics Year 3 microprocessors lab

A simple assembly program for PIC18 microprocessor

Reads a table (message) from programme memory to data memory

Initialises UART and writes a message (the table) to UART 
